from tkinter import *
from tkinter import filedialog
import string
import random
import os
from tkinter import messagebox
from PIL import ImageTk, Image
import os
import hashlib
from Crypto.Cipher import AES
import os

root = Tk()

# Function to browse and select file
def browseFile():
    filepath = filedialog.askopenfilename(title="Select file to encrypt/decrypt", filetypes=(("All files", "*.*"),))
    fileEntry.delete(0, END)
    fileEntry.insert(0, filepath)

# Code to hash a password
def hashPassword(password):
    salt = os.urandom(32)
    key = hashlib.pbkdf2_hmac('sha256', str(password).encode('utf-8'), salt, 100000)
    return salt + key

#code to save the hashed password
def savePassword():
    password = txtPass.get().encode('utf-8')
    keylen = len(password)
    if keylen < 16:
        password += b'\0' * (16 - keylen)
    elif keylen < 24:
        password += b'\0' * (24 - keylen)
    elif keylen < 32:
        password += b'\0' * (32 - keylen)
    else:
        password = password[:32]
    if len(password) == 0:
        messagebox.showwarning("Warning", "Please enter a password")
        return
    hashedPassword = hashPassword(password)
    with open("password.txt", "wb") as f:
        f.write(hashedPassword)
        messagebox.showinfo("Success", "Password saved successfully")

def get_file_type(filepath):
    ext = os.path.splitext(filepath)[1]
    if ext == ".txt":
        return "text"
    elif ext == ".pptx":
        return "powerpoint"
    elif ext == ".jpg" or ext == ".png":
        return "image"
    elif ext == ".zip":
        return "zip"
    else:
        return None

def togglePassword():
    if txtPass["show"] == "*":
        txtPass.config(show="")
        showPasswordBtn.config(text="Hide", bg="#0f0")
    else:
        txtPass.config(show="*")
        showPasswordBtn.config(text="Show", bg="#f00")

# Function to encrypt file using custom algorithm
def custom_encrypt_file(input_file, output_file, key):
    try:
        with open(input_file, 'rb') as f_in:
            data = f_in.read()
    except IOError:
        print(f"Error: Could not read input file {input_file}.")
        return

    encrypted_data = bytearray()
    for i, b in enumerate(data):
        encrypted_data.append(b ^ ord(chr(key[i % len(key)])))


    try:
        with open(output_file, 'wb') as f_out:
            f_out.write(encrypted_data)
    except IOError:
        print(f"Error: Could not write output file {output_file}.")
        return


def custom_decrypt_file(input_file, output_file, key):
    try:
        with open(input_file, 'rb') as f_in:
            data = f_in.read()
    except IOError:
        print(f"Error: Could not read input file {input_file}.")
        return

    decrypted_data = bytearray()
    for i, b in enumerate(data):
        decrypted_data.append(b ^ ord(chr(key[i % len(key)])))

    try:
        with open(output_file, 'wb') as f_out:
            f_out.write(decrypted_data)
    except IOError:
        print(f"Error: Could not write output file {output_file}.")
        return


def encrypt_image(image_file, key):
    output_file = os.path.splitext(image_file)[0] + '_encrypted' + os.path.splitext(image_file)[1]

    try:
        custom_encrypt_file(image_file, output_file, key)
    except Exception as e:
        print(f"Error: An error occurred while encrypting the file: {e}")


def decrypt_image(image_file, key):
    output_file = os.path.splitext(image_file)[0] + '_decrypted' + os.path.splitext(image_file)[1]

    try:
        custom_decrypt_file(image_file, output_file, key)
    except Exception as e:
        print(f"Error: An error occurred while decrypting the file: {e}")


def encrypt_ppt(ppt_file, key):
    output_file = os.path.splitext(ppt_file)[0] + '_encrypted' + os.path.splitext(ppt_file)[1]

    try:
        custom_encrypt_file(ppt_file, output_file, key)
    except Exception as e:
        print(f"Error: An error occurred while encrypting the file: {e}")


def decrypt_ppt(ppt_file, key):
    output_file = os.path.splitext(ppt_file)[0] + '_decrypted' + os.path.splitext(ppt_file)[1]

    try:
        custom_decrypt_file(ppt_file, output_file, key)
    except Exception as e:
        print(f"Error: An error occurred while decrypting the file: {e}")


def encrypt_text(text_file, key):
    output_file = os.path.splitext(text_file)[0] + '_encrypted' + os.path.splitext(text_file)[1]

    try:
        custom_encrypt_file(text_file, output_file, key)
    except Exception as e:
        print(f"Error: An error occurred while encrypting the file: {e}")


def decrypt_text(text_file, key):
    output_file = os.path.splitext(text_file)[0] + '_decrypted' + os.path.splitext(text_file)[1]

    try:
        custom_decrypt_file(text_file, output_file, key)
    except Exception as e:
        print(f"Error: An error occurred while decrypting the file: {e}")

def encrypt_zip(zip_file, key):
    output_file = os.path.splitext(zip_file)[0] + '_encrypted' + os.path.splitext(zip_file)[1]
    try:
        custom_encrypt_file(zip_file, output_file, key)
    except:
        print("Error: An error occurred while encrypting the file.")
        
def decrypt_zip(zip_file, key):
    output_file = os.path.splitext(zip_file)[0] + '_decrypted' + os.path.splitext(zip_file)[1]
    try:
        custom_decrypt_file(zip_file, output_file, key)
    except:
        print("Error: An error occurred while decrypting the file.")


def encryptFile():
    password = txtPass.get().encode('utf-8')
    keylen = len(password)
    if keylen < 8:
        messagebox.showerror("Error", "Password must be at least 8 characters long.")
        return
    try:
        
        if radioBtnVar.get() == "aes":
            # Function to encrypt file using AES algorithm
            filepath = fileEntry.get()
            if not os.path.exists(filepath):
                messagebox.showerror("Error", "Please select a file to encrypt.")
                return
            
            if keylen < 16:
                password += b'\0' * (16 - keylen)
            elif keylen < 24:
                password += b'\0' * (24 - keylen)
            elif keylen < 32:
                password += b'\0' * (32 - keylen)
            else:
                password = password[:32]
            #HAsh and save password
            hashPassword(password)
            savePassword()

            with open(filepath, "rb") as f:
                data = f.read()
            # Pad the data to be a multiple of 16 bytes
            padlen = AES.block_size - (len(data) % AES.block_size)
            data += bytes([padlen])*padlen
            # Create the cipher object and encrypt the data
            cipher = AES.new(password, AES.MODE_ECB)
            encrypted_data = cipher.encrypt(data)
            # Write the encrypted data back to the file
            with open(filepath, "wb") as f:
                f.write(encrypted_data)
            messagebox.showinfo("Success", "File encrypted successfully.")
            
        elif radioBtnVar.get() == "own":
            
            filepath = fileEntry.get()
            file_type = get_file_type(filepath)
            password = txtPass.get().encode('utf-8')

            #HAsh and save password
            hashPassword(password)
            savePassword()


            if file_type == "text":
                encrypt_text(filepath, password)
                messagebox.showinfo("Success", "File encrypted successfully.")
            elif file_type == "powerpoint":
                encrypt_ppt(filepath, password)
                messagebox.showinfo("Success", "File encrypted successfully.")
            elif file_type == "image":
                encrypt_image(filepath, password)
                messagebox.showinfo("Success", "File encrypted successfully.")

            elif file_type == "zip":
                encrypt_zip(filepath, password)
                messagebox.showinfo("Success", "File encrypted successfully.")
            else:
                raise ValueError("Unsupported file type")
            

            # messagebox.showinfo("message" ," Algo Not Defiined yet")
            
    except Exception as e:
            messagebox.showerror("Error", str(e))

# Function to decrypt file using AES algorithm
def decryptFile():

    password = txtPass.get().encode('utf-8')
    keylen = len(password)
    if keylen < 8:
        messagebox.showerror("Error", "Incorrect Password.")
        return

    # Decrypt file
    try:
        if radioBtnVar.get() == "aes":
            filepath = fileEntry.get()
            if not os.path.exists(filepath):
                messagebox.showerror("Error", "Please select a file to decrypt.")
                return
            password = txtPass.get().encode('utf-8')
            keylen = len(password)
            if keylen < 16:
                password += b'\0' * (16 - keylen)
            elif keylen < 24:
                password += b'\0' * (24 - keylen)
            elif keylen < 32:
                password += b'\0' * (32 - keylen)
            else:
                password = password[:32]

            with open(filepath, "rb") as f:
                data = f.read()
            # Create the cipher object and decrypt the data
            cipher = AES.new(password, AES.MODE_ECB)
            decrypted_data = cipher.decrypt(data)
            # Remove the padding
            padlen = decrypted_data[-1]
            decrypted_data = decrypted_data[:-padlen]
            # Write the decrypted data back to the file
            with open(filepath, "wb") as f:
                f.write(decrypted_data)
            messagebox.showinfo("Success", "File decrypted successfully.")
        
        elif radioBtnVar.get() == "own":
            
            filepath = fileEntry.get()
            file_type = get_file_type(filepath)
            password = txtPass.get().encode('utf-8')
            keylen = len(password)
            if keylen < 16:
                password += b'\0' * (16 - keylen)
            elif keylen < 24:
                password += b'\0' * (24 - keylen)
            elif keylen < 32:
                password += b'\0' * (32 - keylen)
            else:
                password = password[:32]

                
            if file_type == "text":
                decrypt_text(filepath, password)
                messagebox.showinfo("Success", "File decrypted successfully.")
            elif file_type == "powerpoint":
                decrypt_ppt(filepath, password)
                messagebox.showinfo("Success", "File decrypted successfully.")
            elif file_type == "image":
                decrypt_image(filepath, password)
                messagebox.showinfo("Success", "File decrypted successfully.")

            elif file_type == "zip":
                decrypt_zip(filepath, password)
                messagebox.showinfo("Success", "File decrypted successfully.")
            else:
                raise ValueError("Unsupported file type")
                #messagebox.showinfo("Algo Not Defiined yet")

    except Exception as e:
                messagebox.showerror("Error", str(e))

root.title("CRYPTOGRAPHY")

#table with 8 rows and 4 columns 
root.rowconfigure(0, weight=1)
root.rowconfigure(1, weight=1)
root.rowconfigure(2, weight=1)
root.rowconfigure(3, weight=1)
root.rowconfigure(4, weight=1)
root.rowconfigure(5, weight=1)
root.rowconfigure(6, weight=1)
root.rowconfigure(7, weight=1)
root.columnconfigure(0, weight=1)
root.columnconfigure(1, weight=1)
root.columnconfigure(2, weight=1)
root.columnconfigure(3, weight=1)

# Load the image and resize it to fit the window
img_path = r"Back.jpg"
img = Image.open(img_path)
img = img.resize((root.winfo_screenwidth(), root.winfo_screenheight()), Image.LANCZOS)
background_image = ImageTk.PhotoImage(img)

# Create a label to hold the image and place it in the window
background_label = Label(root, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

# set the background color of the root window to black
root.configure(bg='#000')

# set the size of the root window
root.geometry("800x400")

lblTitle = Label(root, text="ENCRYPTION AND DECRYPTION", font=("Times New Roman", 16, "bold"), fg='#fff', bg='#000')
lblTitle.grid(row=0, padx=10, pady=10, columnspan=4)

lblSelect = Label(root, text="Please select a File to Encrypt or Decrypt", fg='#fff', bg='#000', font=("Helvetica", 12))
lblSelect.grid(row=1, column=0, padx=10, pady=10, sticky=W, columnspan=2)

fileEntry = Entry(root, width=50, font=("Helvetica", 12))
fileEntry.grid(row=2, column=1, padx=10, pady=10, sticky=W, columnspan=2)

fileLabel = Label(root, text="File path:", fg='#fff', bg='#000', font=("Helvetica", 12))
fileLabel.grid(row=2, column=0, padx=10, pady=10, sticky=W)

openFileBtn = Button(root, text="Browse",command = browseFile , fg='#fff', bg='#00f', font=("Helvetica", 12))
openFileBtn.grid(row=2, column=3, padx=10, pady=10, sticky=W, columnspan=2)

passLabel = Label(root, text="Password:", fg='#fff', bg='#000', font=("Helvetica", 12))
passLabel.grid(row=3, column=0, padx=10, pady=10, sticky=W)

txtPass = Entry(root, width=50, show='*', font=("Helvetica", 12))
txtPass.grid(row=3, column=1, padx=10, pady=10, sticky=W, columnspan=2)

showPasswordBtn = Button(root, text="Show", fg='#fff', bg='#f00', command= togglePassword, font=("Helvetica", 12))
showPasswordBtn.grid(row=3, column=3, padx=10, pady=10, sticky=W)

radioBtnVar = StringVar(value = 'own')

ownRadioBtn = Radiobutton(root, text="Own Algorithm",variable= radioBtnVar, value="own", fg='#fff', bg='#000', selectcolor='red', font=("Helvetica", 12))
ownRadioBtn.grid(row=4, column=0, padx=10, pady=10,sticky=E)

AESRadioBtn = Radiobutton(root, text="AES Algorithm", variable= radioBtnVar ,value="aes", fg='#fff', bg='#000', selectcolor='red', font=("Helvetica", 12))
AESRadioBtn.grid(row=4, column=3, padx=10, pady=10, sticky=W)

btnDecrypt = Button(root, text="Decrypt", fg='#fff', bg='#00f', font=("Times New Roman", 12), width = 20, command = decryptFile)
btnDecrypt.grid(row=5, column=2, padx=10, pady=10, columnspan=2, sticky=W)

btnEncrypt= Button(root, text="Encrypt", fg='#fff', bg='#00f', font=("Times New Roman", 12), width = 20, command = encryptFile)
btnEncrypt.grid(row=5, column=1, padx=10, pady=10, columnspan=2, sticky=W)

root.mainloop()
